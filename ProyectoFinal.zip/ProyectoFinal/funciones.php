<?php 


// FUNCION CONEXION: para saber si hay conexion con la base de datos, sino que salte error

$conexion=function() use($dsn,$user,$password){
	try {
		return new PDO($dsn,$user,$password);
	} catch (PDOException $e) {
		header('Location:../index.php?error='.$e.getCode());
	}

};

// FUNCION SANEAR (RECIBE DATOS): para quitar posibles errores en los datos que se introducen en la base de datos

$sanear=function($dato){

	$dato=trim($dato);
	$dato=htmlspecialchars($dato);
	$dato=stripslashes($dato);

	return $dato;
};

// FUNCION PARA OBTENER LOS ELEMENTOS: para sacar los elementos de las diferentes tablas 

$obtenerDatos=function($tabla) use($conexion){
	$stmt=$conexion()->prepare("SELECT * FROM $tabla");
	$stmt->execute();

	return $stmt->fetchAll();
};


// FUNCION PARA SUBIR EL MENU: para introducir nuevos elementos a carta.view

$subirComida=function($ref,$nombre,$imagen,$descripcion,$alargenos,$precio) use($conexion){
	$stmt=$conexion()->prepare('INSERT INTO comida(ref,nombre,imagen,descripcion,alargenos,precio) VALUES (:ref,:nombre,:imagen,:descripcion,:alargenos,:precio)');
	$stmt->execute([
		':ref'=>$ref,
		':nombre'=>$nombre,
		':imagen'=>$imagen['name'],
		':descripcion'=>$descripcion,
		':alargenos'=>$alargenos,
		':precio'=>$precio
	]);
};

// FUNCION PARA SUBIR LOS EVENTOS: para introducir nuevos elementos a eventos.view

$subirEventos=function($nombre,$imagen,$descripcion,$precio,$fecha,$entrada) use($conexion){
	$stmt=$conexion()->prepare('INSERT INTO eventos(nombre,imagen,descripcion,precio,fecha,entrada) VALUES (:nombre,:imagen,:descripcion,:precio,:fecha,:entrada)');
	$stmt->execute([
		':nombre'=>$nombre,
		':imagen'=>$imagen['name'],
		':descripcion'=>$descripcion,
		':precio'=>$precio,
		':fecha'=>$fecha,
		':entrada'=>$entrada
	]);
};

// FUNCION PARA SUBIR LOS RESERVA: para introducir nuevos elementos a la base de datos de las reservas

$subirReserva=function($nombre,$apellidos,$correo,$telefono,$fecha,$hora,$personas,$comentario) use($conexion){
	$stmt=$conexion()->prepare('INSERT INTO reservas(nombre,apellidos,correo,telefono,fecha,hora,personas,comentario) VALUES (:nombre,:apellidos,:correo,:telefono,:fecha,:hora,:personas,:comentario)');
	$stmt->execute([
		':nombre'=>$nombre,
		':apellidos'=>$apellidos,
		':correo'=>$correo,
		':telefono'=>$telefono,
		':fecha'=>$fecha,
		':hora'=>$hora,
		':personas'=>$personas,
		':comentario'=>$comentario
	]);
};

//FUNCION PAGINA ACTUAL (CAPTURAMOS PAGINA POR GET): saber en que pagina nos encontramos

$paginaActual=function() use($sanear){
	return isset($_GET['p']) ? $sanear((int)$_GET['p']) : 1;
};

// FUNCION QUE OBTENGA EL NUMERO DE PAGINAS (RECIBE ENTRADASPORPAGINA, HEREDE CANEXION Y UTILIZAMOS FUNCION COUNT DE SQL)

$cantidadPaginas=function($entradasPorPagina, $tabla) use($conexion){
	$stmt=$conexion()->prepare("SELECT COUNT(*)numFilas FROM $tabla");

	$stmt->execute();

	$totalFilas=$stmt->fetch()['numFilas'];

	return ceil($totalFilas/$entradasPorPagina);
};

// FUNCION QUE RECOJA EL ID DEL ARTICULO (RECIBE ID Y HEREDA SANEARDATOS)
$capturarId=function($id) use($sanear){
	return isset($id) ? $sanear((int)$id) : false;
};

// FUNCION PARA OBTENER LOS ELEMENTOS: para que pinte paginas segun la cantidad de elementos

$obtenerElementos=function($entradasPorPagina, $tabla) use($conexion, $paginaActual){

	$entradaInicial=$paginaActual()>1 ? $paginaActual()*$entradasPorPagina-$entradasPorPagina : 0;

	$stmt=$conexion()->prepare("SELECT * FROM $tabla LIMIT $entradaInicial,$entradasPorPagina");
	$stmt->execute();

	return $stmt->fetchAll();
};

// FUNCION QUE OBTENGA EL NUMERO DE PAGINAS (RECIBE ENTRADASPORPAGINA, HEREDE CANEXION Y UTILIZAMOS FUNCION COUNT DE SQL)

$cantidadPaginas=function($entradasPorPagina, $tabla) use($conexion){
	$stmt=$conexion()->prepare("SELECT COUNT(*)numFilas FROM $tabla");
	$stmt->execute();
	$totalFilas=$stmt->fetch()['numFilas'];

	return ceil($totalFilas/$entradasPorPagina);
};

// ORDENAR FECHA: para poner la fecha en formato dia/mes/año

$ordenarFecha=function($fecha){
	$fecha=strtotime($fecha);

	$dia=date('d', $fecha);
	$mes=date('m', $fecha);
	$anio=date('Y', $fecha);

	return "$dia/$mes/$anio";
};

// FUNCION QUE COMPRUEBE SI HAY SESION: para logearse en la parte de admin/

$comprobarLogin=function($usuario, $clave) use($conexion){
	$stmt=$conexion()->prepare("SELECT * FROM administrador WHERE usuario=:usuario AND clave=:clave LIMIT 1");
	$stmt->execute([
		':usuario'=>$usuario,
		':clave'=>$clave
	]);
	return $stmt->fetch();
};

// FUNCION PARA ELIMINAR: para eliminar elementos de la base de datos

$eliminarElementos=function($id,$tabla) use($conexion){
	$stmt=$conexion()->prepare("DELETE FROM $tabla WHERE id=:id");
	$stmt->execute([':id'=>$id ]);
};

// FUNCION PARA EDITAR COMIDA: para cambiar los datos de la tabla comida

$editarComida=function($id,$ref,$nombre,$imagen,$descripcion,$alargenos,$precio,$tabla) use($conexion){
	$stmt=$conexion()->prepare("UPDATE $tabla SET ref=:ref,nombre=:nombre,imagen=:imagen,descripcion=:descripcion,alargenos=:alargenos,precio=:precio WHERE id=:id");
	$stmt->execute([
		':id'=>$id,
		':ref'=>$ref,
		':nombre'=>$nombre,
		':imagen'=>$imagen,
		':descripcion'=>$descripcion,
		':alargenos'=>$alargenos,
		':precio'=>$precio
	]);
};

// FUNCION PARA EDITAR EVENTOS: para cambiar los datos de la tabla eventos

$editarEventos=function($id,$nombre,$imagen,$descripcion,$precio,$fecha,$entrada,$tabla) use($conexion){
	$stmt=$conexion()->prepare("UPDATE $tabla SET nombre=:nombre,imagen=:imagen,descripcion=:descripcion,precio=:precio,fecha=:fecha,entrada=:entrada WHERE id=:id");
	$stmt->execute([
		':id'=>$id,
		':nombre'=>$nombre,
		':imagen'=>$imagen,
		':descripcion'=>$descripcion,
		':precio'=>$precio,
		':fecha'=>$fecha,
		':entrada'=>$entrada
	]);
};

// FUNCION QUE OBTENGA EL ARTICULO POR SU ID (RECIBE ID Y HEREDA CONEXION)
$obtenerElementoPorId=function($id, $tabla) use($conexion){
	$stmt=$conexion()->prepare("SELECT * FROM $tabla WHERE id=:id LIMIT 1");
	$stmt->execute([':id'=>$id]);

	return $stmt->fetch();
};











 ?>