<?php session_start();

require_once 'admin/config.php';
require_once 'funciones.php';

$errores='';

// COMPROBAMOS SI HAY CONEXION SNO A ERROR
if(isset($_SESSION['usuario'])){
    header('Location:index.php');
};

$conexion();

// SI HAY SESION ENVIAMOS A ADMIN.PHP

if(isset($_POST['submit'])){
    $usuario=$sanear($_POST['usuario']);
    $clave=$sanear($_POST['clave']);

    // COMPROBAR QUE SE ENVIAN LOS DATOS 

    $login=$comprobarLogin($usuario,$clave);

// CREAMOS LA CONULTA PARA COMPROBAR QUE EL USUARIO Y LA CONTRASEÑA COINCIDEN

    if($login!==false){
        $_SESSION['usuario']=hash('sha512',$usuario);
        header('Location:admin/');
    }else{
        $errores.='Usuario o contraseña incorrecto';
    };
};




require_once 'views/login.view.php';

?>