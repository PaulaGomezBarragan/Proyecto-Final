<?php session_start();

// COMPROBAMOS SI HAY SESION, SI NO HAY ENVIAMOS AL INDEX DEL FRONT
if(!isset($_SESSION['usuario'])){
    header('Location:../index.php');
};

require_once 'config.php';
require_once '../funciones.php';

/*Comprobamos que haya conexion*/
$conexion();


require_once 'views/admin_index.view.php'; 
?>