<div class="paginacion">
	<ul class="pagination justify-content-center">

		<!-- NUMERO PAGINAS -->
		
		<!-- PINTAMOS NUMEROS DE PAGINAS EN FUNCION DE LOS DATOS QUE PINTAMOS POR PAGINA Y MOVEMOS SEGUN LA PAGINA EN LA QUE NOS ENCONTREMOS -->
		<?php for ($i=1; $i <= $totalPaginas; $i++)  :?>

			<li class="page-item bg-dark <?php echo $paginaActual()==$i ? 'active' : false ?>">
				<a href="eventos.php?p=<?php echo $i ?>" class="page-link bg-dark text-white">
					<?php echo $i ?>
				</a>
			</li>

		<?php endfor ; ?>
		

	</ul>
</div>