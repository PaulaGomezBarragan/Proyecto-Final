<?php 

session_start();
require_once 'config.php';
require_once '../funciones.php';

$conexion();

// COMPROBAMOS SI HAY SESION, SINO MANDAMOS A INDEX DEL FRONT

if(!isset($_SESSION['usuario'])){
	header('Location:index.php');
};

// COMPROBAMOS SI HAY CONEXION, SINO A INDEX.PHP
if(!$conexion()){
	header('Location:index.php');
};

// CAPTURAMOS EL ID

$id=$capturarId($_GET['id']);

if(!$id){
	header('Location:index.php');
};

// PREPARAMOS LA CONSULTA DELETE

$eventoEliminado=$eliminarElementos($id, 'eventos');

// ENVIAMOS AL INDEX

header('Location:index.php');



?>