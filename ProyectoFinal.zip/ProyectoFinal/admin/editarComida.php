<?php session_start();

require_once 'config.php';
require_once '../funciones.php';

$conexion();

$errores='';
$subido=false;

// COMPROBAMOS SI HAY SESION, SINO MANDAMOS A INDEX DEL FRONT

if(!isset($_SESSION['usuario'])){
	header('Location:index.php');
};

// COMPROBAMOS SI HAY CONEXION, SINO A INDEX.PHP
if(!$conexion()){
	header('Location:index.php');
};

// COMPROBAMOS QUE SE HAN ENVIADO LOS DATOS
// SI SE HAN ENVIADO LOS CAPTURAMOS 
	// EN EL IF: COMPROBAMOS QUE LOS CAMPOS NO ESTAN VACIOS, SI LO ESTAN CREAMOS EL MENSAJE DE ERROR
	// COMPROBAMOS SI EL FILE ESTA VACIO, SI LO ESTA DECIMOS QUE SEA IGUAL
	// CON EL METODO DE GETIMAGESIZE(NOMBRE) COMPROBAMOS QUE EL ARCHIVO SEA UNA IMG SI NO DEVUELVE FALSE
	// SI ES DISTINTO A FALSE SUBIMOS EL ARCHIVO A LA CARPETA IMG CON EL METODO MOVE UPLOADED FILE(NOMBRE, RUTA)
if(isset($_POST['submit'])){
	$id=$sanear($_POST['id']);
	$ref=$_POST['ref'];
	$nombre=$sanear($_POST['nombre']);
	$precio=$sanear($_POST['precio']);
	$descripcion=$sanear($_POST['descripcion']);
	$alargenos=$sanear($_POST['alargenos']);
	$imagen_guardada=$sanear($_POST['imagen_guardada']);
	$imagen=$_FILES['imagen'];

	if(empty($nombre)){
		$errores.='<li>Debes rellenar el nombre</li>';
	};

	if(empty($precio)){
		$errores.='<li>Debes rellenar el precio</li>';
	};

	if(empty($descripcion)){
		$errores.='<li>Debes rellenar el descripcion</li>';
	};

	if(empty($alargenos)){
		$errores.='<li>Debes rellenar los alargenos con al menos: noAlargeno</li>';
	};

	if(empty($imagen['tmp_name'])){
		$imagen=$imagen_guardada;
	}else{
		$comprobar=getimagesize($imagen['tmp_name']);

		if($comprobar!=false){
			$destino='../rsc/img/comida/'. $imagen['name'];
			move_uploaded_file($imagen['tmp_name'], $destino);

			$imagen=$imagen['name'];
		}else{
			$errores.='<li>El archivo tiene que ser una img</li>';
		};
	};

// FUERA DE LA CONDICIONAL PREPARAMOS LA CONSULTA Y ACTUALIZAMOS LOS DATOS EN LA BBDD
	if(empty($errores)){
		$editarComida($id,$ref,$nombre,$imagen,$descripcion,$alargenos,$precio,'comida');
		header('Location:index.php');
	};

	/*Si no hay enviamos al index del admin*/
}else{
	$id=$capturarId($_GET['id']);

	if($id==false){
		header('Location:index.php');
	};

	$comida=$obtenerElementoPorId($id, 'comida');
	if(!$comida){
		header('Location:index.php');
	};
};







require_once 'views/editarComida.view.php';

?>