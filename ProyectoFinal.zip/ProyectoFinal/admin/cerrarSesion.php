<?php 
/*Comprobar si hay sesion, destruirla y enviar al index fuera de admin/ */
session_start();
session_destroy();

header('Location:../index.php');


?>