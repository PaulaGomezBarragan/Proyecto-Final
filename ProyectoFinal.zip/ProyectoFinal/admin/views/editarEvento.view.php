<?php require_once 'templates/header.php' ?>

<section class="container">
    <h1 class="text-center">Panel de Administración</h1>
    <h2>Editar Evento</h2>

    <!-- Formulario con enctype para subir archivos -->
    <form class="form-control" method="POST" enctype="multipart/form-data" action="">
        <input type="hidden" name="id" value="<?php echo $evento['id'] ?>">
        <!-- Inputs de los datos a modificar -->
        <input type="text" name="nombre" class="form-control" value="<?php echo isset($evento['nombre']) ? $evento['nombre'] : '' ?>" placeholder="Nombre">
        <input type="text" name="precio" class="form-control" value="<?php echo isset($evento['precio']) ? $evento['precio'] : '' ?>" placeholder="Precio">
        <textarea name="descripcion" class="form-control" placeholder="Descripcion"><?php echo isset($evento['descripcion']) ? $evento['descripcion'] : '' ?></textarea>
        <br>
        <input type="date" name="fecha" class="form-control" value="<?php echo $evento['fecha'] ?>">
        <input type="text" name="entrada" class="form-control" value="<?php echo isset($evento['entrada']) ? $evento['entrada'] : '' ?>" placeholder="libre o limitado">
        <input type="file" name="imagen" class="form-control">
        <input type="text" name="imagen_guardada" value="<?php echo isset($evento['imagen']) ? $evento['imagen'] : '' ?>">
        <br>
        <!-- Bloque para los errores -->
        <?php if (!empty($errores)): ?>
            <ul><?php echo $errores ?></ul>
        <?php endif ?>

        <input type="submit" name="submit" value="Editar" class="btn btn-dark form-control">

    </form>

</section>


<?php require_once 'templates/footer.php' ?>