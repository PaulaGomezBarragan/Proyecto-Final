<?php require_once 'templates/header.php' ?>

<section class="container">
    <h1 class="text-center">Panel de Administración</h1>
    <h2>Editar Comida</h2>

    <!-- Formulario con enctype para subir archivos -->
    <form class="form-control" method="POST" enctype="multipart/form-data" action="">
        <input type="hidden" name="id" value="<?php echo $comida['id'] ?>">
        <!-- Selector de la referencia -->
        <select name="ref">
            <option value="americano">Americano</option>
            <option value="hamburguesas">Hamburguesas</option>
            <option value="perritos">Perritos</option>
            <option value="platos">Platos</option>
            <option value="tapas">Tapas</option>
            <option value="montaditos">Montaditos</option>
            <option value="ninos">Niños</option>
            <option value="postres">Postres</option>
        </select>
        <!-- Inputs de los datos a modificar -->
        <input type="text" name="nombre" class="form-control" value="<?php echo isset($comida['nombre']) ? $comida['nombre'] : '' ?>" placeholder="Nombre">
        <input type="text" name="precio" class="form-control" value="<?php echo isset($comida['precio']) ? $comida['precio'] : '' ?>" placeholder="Precio">
        <textarea name="descripcion" class="form-control" placeholder="Descripcion"><?php echo isset($comida['descripcion']) ? $comida['descripcion'] : '' ?></textarea>
        <br>
        <input type="text" name="alargenos" class="form-control" value="<?php echo isset($comida['alargenos']) ? $comida['alargenos'] : '' ?>" placeholder="Alargenos">
        <input type="file" name="imagen" class="form-control">
        <input type="text" name="imagen_guardada" value="<?php echo isset($comida['imagen']) ? $comida['imagen'] : '' ?>">
        <br>

        <!-- Bloque para los errores -->
        <?php if (!empty($errores)): ?>
            <ul><?php echo $errores ?></ul>
        <?php endif ?>

        <input type="submit" name="submit" value="Editar" class="btn btn-dark form-control">

    </form>

</section>


<?php require_once 'templates/footer.php' ?>