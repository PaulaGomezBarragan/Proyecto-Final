<?php require_once 'templates/header.php' ?>

<br>
<section class="contenedorComida">
    <h1 class="hInicio">Panel administrativo de la reserva</h1>


    <br>
    <table class="tablaComida">
        <thead class="cabezaTabla">
            <tr>
                <th class="tTit">&nbsp;</th>
                <th class="tBoton">&nbsp;</th>
                <th class="tBoton">&nbsp;</th>
                <th class="tBoton">&nbsp;</th>
                <th class="tBoton">&nbsp;</th>
                <th class="tBoton">&nbsp;</th>
                <th class="tBoton">&nbsp;</th>
            </tr>
        </thead>

        <tbody>
           <!-- Bucle para mostrar el nombre del dato que recogemos de la tabla reservas y recogemos su id en los botones -->
           <?php foreach ($reservas as $reserva): ?>
            <tr>
                <th class="cuerpoTabla"><?php echo $reserva['nombre'] ?></th>
                <th class="cuerpoTabla"><?php echo $reserva['apellidos'] ?></th>
                <th class="cuerpoTabla"><?php echo $reserva['telefono'] ?></th>
                <th class="cuerpoTabla"><?php echo $ordenarFecha($reserva['fecha']) ?></th>
                <th class="cuerpoTabla"><?php echo $reserva['hora'] ?></th>
                <th class="cuerpoTabla"><?php echo $reserva['personas'] ?></th>
                <td class="cuerpoTabla">
                    <a href="eliminarReservas.php?id=<?php echo $reserva['id'] ?>" class="btn btn-dark">Eliminar</a>
                </td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>
<br>

</section>

<?php require_once 'paginacionReservas.php' ?>


<?php require_once 'templates/footer.php' ?>