<?php require_once 'templates/header.php'; ?>

<section class="contenedorNuevo">
    <br>
    <h1 class="hInicio">Subir evento</h1>
    <!-- Formulario con enctype para subir archivos -->
    <form class="form-control" method="POST" enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>">
        <select name="elegirEntrada">
            <option value="libre">Libre</option>
            <option value="limitado">Limitado</option>
        </select>
        <!-- Inputs de los datos a almacenar -->
        <input type="text" name="nombre" placeholder="Nombre" class="form-control">
        <input type="text" name="precio" placeholder="Precio" class="form-control">
        <textarea name="descripcion" placeholder="Descripcion de la comida" class="form-control"></textarea>
        <input type="date" name="fecha" class="form-control"  min="<?php echo date("Y-m-d");?>" value="<?php echo date("Y-m-d");?>">
        <input type="file" name="imagen" class="form-control">
        
        <?php if (!empty($errores)): ?>
            <ul><?php echo $errores ?></ul>
        <?php endif ?>
        
        <br>
        <div class="cajaBoton">
            <input type="submit" name="submit" value="Crear nuevo" class="btn btn-dark form-control">
        </div>
    </form>
</section>




<?php require_once 'templates/footer.php'; ?>