<?php require_once 'templates/header.php' ?>

<br>
<h1 class="hInicio">PANEL DE ADMINISTRACIÓN</h1>
<br>

<!-- Enlaces a las paginas -->
<div class="contenedorBotones">
	<a href="carta.php" class="enlaceAdmin">Carta</a>
	<a href="eventos.php" class="enlaceAdmin">Eventos</a>
	<a href="reserva.php" class="enlaceAdmin">Reserva</a>
</div>


<!-- Boton para cerrar sesion -->
<div class="cajaCerrar">
	<a href="cerrarSesion.php" class="enlaceCerrar">Cerrar Sesión</a>
</div>
<br>


<?php require_once 'templates/footer.php' ?>