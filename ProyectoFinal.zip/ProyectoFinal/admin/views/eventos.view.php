<?php require_once 'templates/header.php' ?>

<br>
<section class="contenedorComida">
    <h1 class="hInicio">Panel administrativo de eventos</h1>
    <div class="cajaBotonNuevo">
        <a href="nuevoEvento.php" class="btn btn-dark">Añadir Nuevo</a>
    </div>

    <br>
    <table class="tablaComida">
        <thead class="cabezaTabla">
            <tr>
                <th class="tTit">&nbsp;</th>
                <th class="tBoton">&nbsp;</th>
                <th class="tBoton">&nbsp;</th>
            </tr>
        </thead>

        <tbody>
         <!-- Bucle para mostrar el nombre del dato que recogemos de la tabla eventos y recogemos su id en los botones -->
         <?php foreach ($eventos as $evento): ?>
            <tr>
                <th class="cuerpoTabla"><?php echo $evento['nombre'] ?></th>
                <td class="cuerpoTabla">
                    <a href="editarEvento.php?id=<?php echo $evento['id'] ?>" class="btn btn-dark">Editar</a>
                </td>
                <td class="cuerpoTabla">
                    <a href="eliminarEventos.php?id=<?php echo $evento['id'] ?>" class="btn btn-dark">Eliminar</a>
                </td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>
<br>

</section>

<?php require_once 'paginacionEventos.php' ?>


<?php require_once 'templates/footer.php' ?>