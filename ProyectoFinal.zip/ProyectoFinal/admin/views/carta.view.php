<?php require_once 'templates/header.php' ?>

<br>
<section class="contenedorComida">
    <h1 class="hInicio">Panel administrativo de la carta</h1>
    <div class="cajaBotonNuevo">
        <a href="nuevaComida.php" class="btn btn-dark">Añadir Nuevo</a>
    </div>

    <br>
    <table class="tablaComida">
        <thead class="cabezaTabla">
            <tr>
                <th class="tTit">&nbsp;</th>
                <th class="tBoton">&nbsp;</th>
                <th class="tBoton">&nbsp;</th>
            </tr>
        </thead>

        <tbody>
            <!-- Bucle para mostrar el nombre del dato que recogemos de la tabla comidas y recogemos su id en los botones -->
            <?php foreach ($comidas as $comida): ?>
                <tr>
                    <th class="cuerpoTabla"><?php echo $comida['nombre'] ?></th>
                    <td class="cuerpoTabla">
                        <a href="editarComida.php?id=<?php echo $comida['id'] ?>" class="btn btn-dark">Editar</a>
                    </td>
                    <td class="cuerpoTabla">
                        <a href="eliminarComida.php?id=<?php echo $comida['id'] ?>" class="btn btn-dark">Eliminar</a>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
    <br>

</section>


<?php require_once 'paginacion.php' ?>


<?php require_once 'templates/footer.php' ?>