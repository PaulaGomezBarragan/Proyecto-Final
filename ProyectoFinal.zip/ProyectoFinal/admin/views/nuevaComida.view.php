<?php require_once 'templates/header.php'; ?>

<section class="contenedorNuevo">
    <br>
    <h1 class="hInicio">Subir comida</h1>
    <!-- Formulario con enctype para subir archivos -->
    <form class="formularioNuevaComida" method="POST" enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>">
        <select name="elegirReferencia">
            <option value="americano">Americano</option>
            <option value="hamburguesas">Hamburguesas</option>
            <option value="perritos">Perritos</option>
            <option value="platos">Platos</option>
            <option value="tapas">Tapas</option>
            <option value="montaditos">Montaditos</option>
            <option value="ninos">Niños</option>
            <option value="postres">Postres</option>
        </select>
        <!-- Inputs de los datos a almacenar -->
        <input type="text" name="nombre" placeholder="Nombre" class="inputNuevaComida">
        <input type="text" name="precio" placeholder="Precio" class="inputNuevaComida">
        <textarea name="descripcion" placeholder="Descripcion de la comida" class="inputNuevaComida"></textarea>
        <input type="file" name="imagen" class="inputNuevaComida">
        <div class="cajaAlargeno">
            <input type="checkbox" name="alargeno[]" value="noAlargeno" checked>
            <label>Sin Alargenos</label>

            <input type="checkbox" name="alargeno[]" value="lacteos">
            <label>Lacteos</label>

            <input type="checkbox" name="alargeno[]" value="huevos">
            <label>Huevos</label>

            <input type="checkbox" name="alargeno[]" value="almendra">
            <label>Almendra</label>

            <input type="checkbox" name="alargeno[]" value="apio">
            <label>Apio</label>

            <input type="checkbox" name="alargeno[]" value="cacahuete">
            <label>Cacahuete</label>

            <input type="checkbox" name="alargeno[]" value="cangrejo">
            <label>Cangrejo</label>

            <input type="checkbox" name="alargeno[]" value="cascara">
            <label>Cascaras</label>
        </div>
        <div>
            <input type="checkbox" name="alargeno[]" value="garbanzos">
            <label>Garbanzos</label>

            <input type="checkbox" name="alargeno[]" value="mostaza">
            <label>Mostaza</label>

            <input type="checkbox" name="alargeno[]" value="pescado">
            <label>Pescado</label>

            <input type="checkbox" name="alargeno[]" value="trigo">
            <label>Trigo</label>

            <input type="checkbox" name="alargeno[]" value="sulfito">
            <label>Sulfito</label>
            
            <input type="checkbox" name="alargeno[]" value="soja">
            <label>Soja</label>
            
            <input type="checkbox" name="alargeno[]" value="sesamo">
            <label>Sésamo</label>
        </div>
        
        <?php if (!empty($errores)): ?>
            <ul><?php echo $errores ?></ul>
        <?php endif ?>
        
        <br>
        <div class="cajaBoton">
            <input type="submit" name="submit" value="Crear nuevo" class="btnEnviarComida">
        </div>
    </form>
</section>




<?php require_once 'templates/footer.php'; ?>