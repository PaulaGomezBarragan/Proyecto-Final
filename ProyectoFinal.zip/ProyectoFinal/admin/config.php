<?php 

/*Variables para saber en que base de datos estoy*/
$host='localhost';
$dbName='ruta_66';
$user='paula';
$password='123';

$dsn="mysql:host=$host;dbname=$dbName;charset=utf8";

/*Objeto para pintar 8 datos por pagina*/
$admin_config=[
    'entradasPorPaginas'=>8
];

?>