<?php 

session_start();

require_once 'config.php';
require_once '../funciones.php';


// COMPROBAMOS SI HAY SESION, SINO A INDEX DEL FRONT
if(!isset($_SESSION['usuario'])){
    header('Location: ../index.php');
};

// COMPROBAMOS SI HAY CONEXION SINO A INDEX
$conexion();

$errores='';
$subido=false;

// COMPROBAMOS SI SE HAN ENVIADO LOS DATOS DEL FORMULARIO Y LOS RECOGEMOS
if(isset($_POST['submit'])){
    $nombre=$sanear($_POST['nombre']);
    $descripcion=$sanear($_POST['descripcion']);
    $precio=$sanear($_POST['precio']);
    $fecha=$_POST['fecha'];
    $entrada=$_POST['elegirEntrada'];

// RECOGEMOS EL ARCHIVO DE IMG CON $_FILES
    $imagen=$_FILES['imagen'];

    if(empty($nombre)){
        $errores.='<li>Debes rellenar el nombre</li>';
    };

    if(empty($precio)){
        $errores.='<li>Debes rellenar el precio</li>';
    };

    if(empty($descripcion)){
        $errores.='<li>Debes rellenar la descripcion</li>';
    };

    if(empty($imagen)){
        $errores.='<li>Debes insertar imagen</li>';
    }else{
        // CON EL METODO GETIMAGESIZE COMPROBAMOS QUE EL ARCHIVO QUE DA ES UNA IMG, SINO QUE DEVUELVA FALSE
        $comprobar=getimagesize($imagen['tmp_name']);
        if($comprobar==false){
            $errores.='<li>Debes insertar una imagen</li>';
        };
    };

// PREPARAMOS LA CONSULTA Y SUBIMOS LOS DATOS A LA BD
    if(empty($errores)){
        $subirEventos($nombre,$imagen,$descripcion,$precio,$fecha,$entrada);
        $subido=true;
    };

// SI ES DISTINTO A FALSE, SUBIMOS EL ARCHIVO A LA CARPETA IMG CON EL METODO MOVE UPLOADED FILE
    if($subido){
        $rutaImagen='../rsc/img/eventos/'.$imagen['name'];
        move_uploaded_file($imagen['tmp_name'], $rutaImagen);
    };
};



require_once 'views/nuevoEvento.view.php';


?>