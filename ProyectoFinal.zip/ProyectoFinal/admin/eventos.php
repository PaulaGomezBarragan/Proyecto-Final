<?php session_start();

// COMPROBAMOS SI HAY SESION, SI NO HAY ENVIAMOS AL INDEX DEL FRONT
if(!isset($_SESSION['usuario'])){
    header('Location:../index.php');
};

require_once 'config.php';
require_once '../funciones.php';

$conexion();

/*Comprobamos que haya conexion y recogemos los datos. Pintamos segun la cantidad de datos y por cantidas de paginas*/
$eventos=$obtenerElementos($admin_config['entradasPorPaginas'], 'eventos');

if(!$eventos){
    header('Location:index.php');
};

$totalPaginas=$cantidadPaginas($admin_config['entradasPorPaginas'], 'eventos');


require_once 'views/eventos.view.php'; 
?>