<?php session_start();

// COMPROBAMOS SI HAY SESION, SI NO HAY ENVIAMOS AL INDEX DEL FRONT
if(!isset($_SESSION['usuario'])){
    header('Location:../index.php');
};

require_once 'config.php';
require_once '../funciones.php';

/*COMPROBAMOS QUE HAY CONEXION*/
$conexion();
/*Comprobamos que haya conexion y recogemos los datos. Pintamos segun la cantidad de datos y por cantidas de paginas*/
$reservas=$obtenerElementos($admin_config['entradasPorPaginas'], 'reservas');

if(!$reservas){
    header('Location:index.php');
};

$totalPaginas=$cantidadPaginas($admin_config['entradasPorPaginas'], 'reservas');

require_once 'views/reserva.view.php'; 
?>