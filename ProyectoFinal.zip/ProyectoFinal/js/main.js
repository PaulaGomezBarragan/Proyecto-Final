 'use strict'

window.addEventListener('load', ()=>{
  let fragment;

  // JS DE HEADER.PHP

/*Variables para mostrar el menu oculto*/
  const iconoMenu=document.getElementById('iconoMenu');
  const menuDesplegable=document.querySelector('#menuDesplegable');

/*Evento para mostrar el menu desplegable*/
  iconoMenu.addEventListener('click', ()=>{
    mostrarMenuOculto();

  })

/*Funcion para mostrar el menu desplegable*/
  const mostrarMenuOculto=()=>{
    if(menuDesplegable.style.display=='block'){
      menuDesplegable.style.display="none";
      iconoMenu.setAttribute('src', 'rsc/img/iconos/menuAzul.png');
    }else{
      menuDesplegable.style.display="block";
      iconoMenu.setAttribute('src', 'rsc/img/iconos/equisAzul.png');
    }
  }

  // JS DE INDEX
/*Constantes para cambiar las imagenes del index*/
  const cajaSlider=document.querySelectorAll('#cajaSlider');
  const contenedorSlider=document.getElementById('contenedorSlider');

  let indice=1;


  if(contenedorSlider){
    /*Evento para mover las fotos del slider*/
    contenedorSlider.addEventListener('click', ev=>{
      if(ev.target.matches('#antes')) moverFoto(-1);
  
      if(ev.target.matches('#despues')) moverFoto(1);
    })

/*Funcion para saber en que posicion de foto estoy y mover acorde a ella*/
    const pasarFoto=num=>{
      if (num > cajaSlider.length) indice = 1
        if (num < 1) indice = cajaSlider.length
          for (let i = 0; i < cajaSlider.length; i++) {
            cajaSlider[i].style.display = "none";
          }
          cajaSlider[indice-1].style.display = "block";
        }

/*Funcion para mover la foto*/
    const moverFoto=num=>pasarFoto(indice+=num);

    pasarFoto(indice);
      }




});
