'use strict'

/*Evento para que se cargue la pagina totalmente*/
window.addEventListener('load', ()=>{

let fragment;

/*Recogemos el boton para que se muestren los filtros, el formulario y los dos filtros que contiene*/
const filtroEventos=document.querySelector('#filtroEventos');
const formularioFiltro=document.querySelector('#formularioFiltro');
const elegirMes=document.querySelector('#elegirMes');
const elegirPrecio=document.querySelector('#elegirPrecio');
const eventosFiltrados=document.querySelector('#eventosFiltrados');

let verFiltros=false;
let respuestaJson;
let arrayFiltro;

/*Para que no de error en otras paginas le añado un if de si contiene una variable especifica de la pagina*/
if(filtroEventos){
  /*Evento para mostrar los filtros*/
  filtroEventos.addEventListener('click', ev=>{
    mostrarFiltros();
  })

/*Evento para cambiar sin recargar la pagina los eventos filtrados*/
  formularioFiltro.addEventListener('change', (ev)=>{
    ev.preventDefault();
    getJson();
  })

/*Funcion para mostrar / ocultar los filtros de los eventos*/
  const mostrarFiltros=()=>{
    if(verFiltros){
      formularioFiltro.style.display='none';
      verFiltros=false;
    }else{
      formularioFiltro.style.display='block';
       verFiltros=true;
    }
  }

/*Funcion para obtener la respuesta json */
  const getJson= async()=>{
    try{
      const respuesta=await fetch('recogerEventos.php');
      if(respuesta.ok){
        respuestaJson=await respuesta.json();
        filtrarEventos();
      }else{
        throw 'Error en json';
      }
    }catch(err){
      console.log(err);
    }
  }

/*Funcion para filtrar tanto por mes como por precio*/
  const filtrarEventos=()=>{

   if(elegirMes.value=='mostrarTodosMeses' && elegirPrecio.value=='mostrarTodosPrecios'){
    arrayFiltro=respuestaJson;
  }else{
    if(elegirMes.value!='mostrarTodosMeses' && elegirPrecio.value=='mostrarTodosPrecios'){
      arrayFiltro=respuestaJson.filter(item=>item.fecha.substring(4,5)==elegirMes.value);
    }else if(elegirPrecio.value!='mostrarTodosPrecios' && elegirMes.value=='mostrarTodosMeses'){
      arrayFiltro=respuestaJson.filter(item=>item.entrada==elegirPrecio.value);
    }else{
      arrayFiltro=respuestaJson.filter(item=>(item.fecha.substring(4,5)==elegirMes.value) && (item.entrada==elegirPrecio.value));
    }
  }
  return pintarEventos(arrayFiltro);
}

/*Funcion para pintar los eventos que reciba por el array*/
const pintarEventos=(array)=>{
  eventosFiltrados.innerHTML='';

  if(arrayFiltro.length>0){
    fragment= document.createDocumentFragment();

    arrayFiltro.forEach(elemento=>{
      const articulo= document.createElement('ARTICLE');
      const cajaEvento1= document.createElement('DIV');
      const cajaEvento2= document.createElement('DIV');

      const imagen= document.createElement('IMG');
      const h3= document.createElement('H3');
      const descripcion= document.createElement('P');
      const fecha= document.createElement('P');
      const precio= document.createElement('SPAN');
      const ticket= document.createElement('IMG');

      articulo.classList.add('contenedorEvento');
      cajaEvento1.classList.add('cajaEvento1');
      cajaEvento2.classList.add('cajaEvento2');

      imagen.setAttribute('src', `rsc/img/eventos/${elemento.imagen}`);
      imagen.setAttribute('alt', `${elemento.imagen}`);
      imagen.classList.add('imagenEvento');

      h3.classList.add('nombreEvento');
      descripcion.classList.add('descripcionEvento');
      fecha.classList.add('fechaEvento');
      precio.classList.add('precioEvento');
      ticket.setAttribute('src', `rsc/img/iconos/ticket.png`);
      ticket.setAttribute('alt', `icono de ticket`);
      ticket.setAttribute('title', `icono de ticket`);
      ticket.classList.add('iconoTicket');

      h3.innerHTML=elemento.nombre;
      descripcion.innerHTML=elemento.descripcion;
      fecha.innerHTML=elemento.fecha;
      precio.innerHTML=elemento.precio;

      precio.style.fontWeight='bold';

      cajaEvento1.append(imagen);
      cajaEvento2.append(h3);
      cajaEvento2.append(descripcion);
      cajaEvento2.append(fecha);
      cajaEvento2.append(precio);
      cajaEvento2.append(ticket);


      articulo.append(cajaEvento1);
      articulo.append(cajaEvento2);

      fragment.append(articulo);
    })

    eventosFiltrados.append(fragment);

  }else{
    if(elegirMes.value!='mostrarTodosMeses'){
      console.log('entra');
      eventosFiltrados.innerHTML='<p>Lo sentimos, no hay eventos que coincidan con la búsqueda.</p>';
    }
  }

}

/*Llamada al json para que se pinten antes de aplicar ningun filtro*/
getJson();

}
  
});