'use strict'

window.addEventListener('load', ()=>{
    let fragment;

/*Recojo los elementos en los que voy a realizar los eventos de cambio*/
    const horaLlegada=document.querySelector('#horaLlegada');
    const cajaCalendarioHoras=document.querySelector('#cajaCalendarioHoras');
    const formularioReservas=document.querySelector('#formularioReservas');
    const cajaDatos=document.querySelector('#cajaDatos');
    const cajaFinalReservas=document.querySelector('#cajaFinalReservas');

/*Recojo los iconos para mostrarlos / cambiarlos segun el paso en el que me encuentre*/
    const iconoProgreso1=document.querySelector('#iconoProgreso1');
    const iconoProgreso2=document.querySelector('#iconoProgreso2');
    const iconoProgreso3=document.querySelector('#iconoProgreso3');
    const enlaceVolver=document.querySelector('#enlaceVolver');

/*Recojo los campos que rellena el usuario para validarlos*/
    const campoNombre=document.getElementById('campoNombre');
    const campoApellidos=document.getElementById('campoApellidos');
    const campoCorreo=document.getElementById('campoCorreo');
    const campoTelefono=document.getElementById('campoTelefono');

/*Expresiones regulares para validar*/
    let regExp={
        nombre:/^([A-ZÁÉÍÓÚ]{1}[a-zñáéíóú]+[\s]*)+$/,
        apellidos:/^([A-ZÁÉÍÓÚ]{1}[a-zñáéíóú]+[\s]*)+$/,
        correo:/^[\w]+@{1}[\w]+\.[a-z]{2,3}$/,
        telefono:/^[9|6]{1}([\d]{2}[-]*){3}[\d]{2}$/
    }

    let datosValidar={
        nombre:false,
        apellidos:false,
        correo:false,
        telefono:false
    }

    if(formularioReservas){
/*Evento para cambiar al paso dos de escribir los datos*/
        horaLlegada.addEventListener('click', ev=>{
            if(ev.target.matches('input')){
                cambiarADatos();
            }
        });

/*Evento submit para validar*/
        formularioReservas.addEventListener('submit', ev=>{
            validarDatos();
      })

/*Funcion para mostrar los inputs para escribir nuestros datos*/
        const cambiarADatos=()=>{
            cajaCalendarioHoras.style.display='none';
            cajaDatos.removeAttribute('hidden');
            enlaceVolver.removeAttribute('hidden');
            iconoProgreso1.setAttribute('src', 'rsc/img/iconos/bien.png');
            iconoProgreso2.setAttribute('src', 'rsc/img/iconos/dosSeleccionado.png');
        }

/*Funcion para mostrar la parte final del formulario*/
        const enviarDatos=()=>{
            ev.preventDefault();
            cajaFinalReservas.removeAttribute('hidden');
            cajaCalendarioHoras.style.display='none';
            cajaDatos.style.display='none';
            enlaceVolver.hidden=true;
            iconoProgreso1.setAttribute('src', 'rsc/img/iconos/bien.png');
            iconoProgreso2.setAttribute('src', 'rsc/img/iconos/bien.png');
            iconoProgreso3.setAttribute('src', 'rsc/img/iconos/tresSeleccionado.png');
      }

/*Clase para validar los datos*/
      class DatosPersonas{
        constructor(nombre,apellidos,correo,telefono){
            this._nombre=nombre;
            this._apellidos=apellidos;
            this._correo=correo;
            this._telefono=telefono;
        }

        get nombre(){
            return this._nombre;
        }

        get apellidos(){
            return this._apellidos;
        }

        get correo(){
            return this._correo;
        }

        get telefono(){
            return this._telefono;
        }
    }


/*Funcion para validar los datos con la expresion regular*/
    const validarDatos=()=>{
        if(regExp.nombre.test(campoNombre.value)){
            datosValidar.nombre=true;
        }else{
            datosValidar.nombre=false;
        }

        if(regExp.apellidos.test(campoApellidos.value)){
            datosValidar.apellidos=true;
        }else{
            datosValidar.apellidos=false;
        }

        if(regExp.correo.test(campoCorreo.value)){
            datosValidar.correo=true;
        }else{
            datosValidar.correo=false;
        }

        if(regExp.telefono.test(campoTelefono.value)){
            datosValidar.telefono=true;
        }else{
            datosValidar.telefono=false;
        }

        let arrayValidados=Object.values(datosValidar);
        let indiceFalso=arrayValidados.findIndex(item=>item==false);

/*Condicional para mostrar errores o enviar los datos a la base de datos*/
        if(indiceFalso==-1){
           enviarDatos();
        }else{
            switch(indiceFalso){
              case 0:
              alert('Nombre no valido');
              break;
              case 1:
              alert('Apellidos no valido');
              break;
              case 2:
              alert('Correo no valido');
              break;
              case 3:
              alert('Telefono no valido');
              break;
          }
      }
  }

}


});