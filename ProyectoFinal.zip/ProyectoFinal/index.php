<?php 

require_once 'admin/config.php';
require_once 'funciones.php';

/*Comprobar si hay conexion*/
$conexion();

require_once 'views/index.view.php';

?>