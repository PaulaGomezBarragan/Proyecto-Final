<?php 

require_once 'admin/config.php';
require_once 'funciones.php';

/*Convertir pagina en un json*/
header('Content-type:application/json;charset=utf-8');

/*Comprobar si hay conexion*/
$conexion();

$resultado=[];

/*Si no hay conexion a error, si hay conexion rescatar los datos*/
if(!$conexion()){
	$resultado=['error'=>'ERROR'];
}else{
	$stmt=$conexion()->prepare("SELECT * FROM eventos");
	$stmt->execute();

	while ($dato=$stmt->fetch()) {
		$evento=[
			'id'=>$dato['id'],
			'nombre'=>$dato['nombre'],
			'imagen'=>$dato['imagen'],
			'descripcion'=>$dato['descripcion'],
			'fecha'=>$ordenarFecha($dato['fecha']),
			'precio'=>$dato['precio'],
			'entrada'=>$dato['entrada']
		];
		array_push($resultado, $evento);
	};

};

/*Pintar los datos json*/
echo json_encode($resultado);


?>