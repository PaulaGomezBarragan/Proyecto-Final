<?php require_once 'templates/header.php' ?>

<br>
<div class="contenedorSeparador">
	<hr class="lineaAmarilla">
	<h2 class="tituloReserva">Reservar Mesa</h2>
	<hr class="lineaAmarilla">
</div>
<br>

<div class="contenedorReservas">
	<form action="" method="POST" id="formularioReservas" class="formularioReservas">
		<!-- Iconos que indican el progreso y para poder volver atras -->
		<div class="cajaProgreso">
			<a href="reserva.php" class="enlaceVolver" id="enlaceVolver" hidden>
				<img src="rsc/img/iconos/volver.png" class="volver" id="volver">
			</a>
			<img src="rsc/img/iconos/numero-1.png" class="iconoProgreso" id="iconoProgreso1">
			<img src="rsc/img/iconos/numero-2.png" class="iconoProgreso" id="iconoProgreso2">
			<img src="rsc/img/iconos/numero-3.png" class="iconoProgreso" id="iconoProgreso3">
		</div>
		<br>
		<div class="cajaCalendarioHoras" id="cajaCalendarioHoras">
			<!-- Input con la fecha -->
			<div class="cajaCalendario" >
				<input type="date" name="fecha" value="<?php echo date("Y-m-d");?>" min="<?php echo date("Y-m-d");?>" id="fecha" required>
				<!-- Select para selecionar la cantidad de personas -->
				<select class="cantidadPersonas" name="cantidadPersonas" id="cantidadPersonas">
					<option value="1 persona">1 Persona</option>
					<option value="2 personas" selected>2 Personas</option>
					<option value="3 personas">3 Personas</option>
					<option value="4 personas">4 Personas</option>
					<option value="5 personas">5 Personas</option>
					<option value="6 personas">6 Personas</option>
					<option value="7 personas">7 Personas</option>
					<option value="8 personas">8 Personas</option>
				</select>
				<p class="pReserva">*Para reservar grupos mayores de 8 personas, por favor llamar a +34 612 345 678</p>
			</div>
			<!-- Hora de llegada de la reserva tanto almuerzo como cena -->
			<div class="horaLlegada" id="horaLlegada">
				<div class="almuerzo">
					<p class="pHoras">Horario Comida</p>
					<div class="cajaHorarios">
						<input type="radio" name="horas" value="13:00" id="horas">
						<label for="horas" class="hora">13:00</label>
						<input type="radio" name="horas" value="13:30" id="hora2">
						<label for="hora2" class="hora">13:30</label>
						<input type="radio" name="horas" value="13:45" id="hora3">
						<label for="hora3" class="hora">13:45</label>
						<input type="radio" name="horas" value="14:00" id="hora4">
						<label for="hora4" class="hora">14:00</label>
						<input type="radio" name="horas" value="14:30" id="hora5">
						<label for="hora5" class="hora">14:30</label>
					</div>
				</div>
				<div class="cena">
					<p class="pHoras">Horario Cena</p>
					<div class="cajaHorarios">
						<input type="radio" name="horas" value="21:00" id="hora6">
						<label for="hora6" class="hora">21:00</label>
						<input type="radio" name="horas" value="21:30" id="hora7">
						<label for="hora7" class="hora">21:30</label>
						<input type="radio" name="horas" value="21:45" id="hora8">
						<label for="hora8" class="hora">21:45</label>
						<input type="radio" name="horas" value="22:00" id="hora9">
						<label for="hora9" class="hora">22:00</label>
						<input type="radio" name="horas" value="22:30" id="hora10">
						<label for="hora10" class="hora">22:30</label>
					</div>
				</div>
			</div>
		</div>
		<!-- Input de datos del cliente -->
		<div class="cajaDatos" id="cajaDatos" hidden>
			<div class="cajaDatos1">
				<input type="text" name="nombre" placeholder="Nombre" class="datoReserva" id="campoNombre" required>
				<input type="text" name="apellidos" placeholder="Apellido" class="datoReserva" id="campoApellidos" required>
			</div>
			<div class="cajaDatos2">
				<input type="text" name="correo" placeholder="Email" class="datoReserva" id="campoCorreo" required>
				<input type="text" name="telefono" placeholder="Móvil" class="datoReserva" id="campoTelefono" required>
			</div>
			<textarea class="comentario" name="descripcion" placeholder="Escribe un comentario sobre la reserva"></textarea>
			<br>
			<div class="cajaPermisos">
				<label><input type="checkbox" required>Acepto las condiciones de uso, política de privacidad y aviso legal</label>
				<label for="cbox2"><input type="checkbox" required> Consiento el tratamiento de mis datos personales</label>
			</div>
			<br>
			<?php if (!empty($errores)): ?>
				<ul><?php echo $errores ?></ul>
			<?php endif ?>
			<br>
			<input type="submit" name="submit" class="btnReservar" value="Reservar">
			<br>
		</div>
		<br>

		<div id="cajaFinalReservas" hidden>
			<h3 class="hReserva">Gracias por reservar con nosotros</h3>
			<br>
			<p class="pReserva">Se ha enviado un email con la confirmación de la reserva</p>
		</div>

	</form>

</div>


<?php require_once 'templates/footer.php' ?>