<?php require_once 'templates/header.php' ?>

<section class="contenedorLogin">
	<br>
	<h1 class="hInicio">Iniciar Sesion</h1>
<!-- Formulario para logearse con un parrafo para los errores -->
	<form class="formularioLogin" action="" method="POST" name="login">
		<input type="text" name="usuario" placeholder="Usuario" class="inputLogin">
		<input type="password" name="clave" placeholder="Contraseña" class="inputLogin">

		<?php if (!empty($errores)): ?>
			<p><?php echo $errores ?></p>
		<?php endif ?>
		
		<input type="submit" name="submit" class="botonLogin" value="Acceder">
	</form>
</section>

<?php require_once 'templates/footer.php' ?>