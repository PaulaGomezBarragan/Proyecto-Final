<?php require_once 'templates/header.php' ?>

<!-- Contenedor de los slider -->
<div class="contenedorSlider" id="contenedorSlider">

  <div class="cajaSlider" id="cajaSlider">
   <img src="rsc/img/fotoSlider1.jpg" class="imgSlider" alt="foto de comida">
 </div>

 <div class="cajaSlider" id="cajaSlider">
  <img src="rsc/img/fotoSlider2.jpg" class="imgSlider" alt="foto de comida">
</div>

<div class="cajaSlider" id="cajaSlider">
  <img src="rsc/img/fotoSlider3.jpg" class="imgSlider" alt="foto de comida">
</div>

<div class="cajaSlider" id="cajaSlider">
  <img src="rsc/img/fotoSlider4.jpg" class="imgSlider" alt="foto de comida">
</div>

<div class="fotoMovil"></div>

<div class="antes"><img src="rsc/img/iconos/left.png" class="flechas" id="antes"></div>
<div class="despues"><img src="rsc/img/iconos/right.png" class="flechas" id="despues"></div>

<div class="contenedorBotones">
  <button class="cartaHeader"><a href="carta.php" class="enlace enlaceHeader">Ver Carta</a></button>
  <button class="reservaHeader"><a href="reserva.php" class="enlace enlaceHeader">Reserva Ahora</a></button>
</div>

</div>

<!-- Contenedor de informacion -->
<div class="contenedorInfo">
  <article class="historia">
    <h2>Nuestra Historia</h2>
    <hr class="lineaAmarilla">
    <p>Desde el primer día, facilitamos a nuestros empleados todas las herramientas y formación necesarias para dominar su puesto de trabajo. Y esta formación se prolonga y amplía durante todo el tiempo que una persona permanezca en la compañía. Por eso decimos que “Ruta 66 va contigo”: porque la experiencia y la formación que adquieren nuestros empleados les acompaña toda su vida, independientemente del camino profesional que elijan.
    En Ruta 66 apostamos por la flexibilidad horaria para que nuestros empleados puedan adaptar su trabajo a su estilo de vida.
    </p>
  </article>
  <article class="mision">
    <h2>Nuestra Mision</h2>
    <hr class="lineaAmarilla lineaDerecha">
    <p>La aspiración de Ruta 66 es desarrollar y operar restaurantes con un alto nivel de eficiencia, capaces de generar valor no sólo en el propio negocio, sino también en las comunidades donde están presentes. Los empleados de Ruta 66 son el principal activo de la compañía. Algunos de ellos vienen sólo para un verano, y otras se quedan toda la vida, porque en Ruta 66 siempre hay oportunidades para crecer.</p>
    <p>Llevamos diez años implementando medidas de eficiencia energética, diseñando nuestro restaurante con instalaciones eficientes en todo lo referente a cocina, iluminación y climatización. Monitorizamos el consumo eléctrico, y más del 95% de nuestros restaurantes ya funcionan con energías renovables.</p>

  </article>
</div>

<!-- Bloque final con el mapa y redes sociales -->
<div class="contenedorMapa">
  <h2 class="h2Mapa">Donde Estamos</h2>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3172.022978631259!2d-5.94010688486613!3d37.341964679840586!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd126fb5987fb429%3A0x34a66cff43ca7253!2sRUTA%2066%20SEVILLA!5e0!3m2!1ses!2ses!4v1672765811147!5m2!1ses!2ses" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="enlaceMapa"></iframe>

    <div class="contacto">

    <section>
      <img src="rsc/img/iconos/telefono.png" class="iconoMapa">
      <span class="datoSpan">612 345 789</span>
    </section>
    <section>
      <img src="rsc/img/iconos/email.png" class="iconoMapa">
      <span class="datoSpan">ruta66@ruta.com</span>
    </section>
    <section>
      <img src="rsc/img/iconos/local.png" class="iconoMapa">
      <span class="datoSpan">C. Calígula, 14, Montequinto</span>
    </section>
  </div>

   <div class="redes">
    <section class="datosRedes">
      <a href="https://es-la.facebook.com/Ruta66sevillaDH/" target="blank"><img src="rsc/img/iconos/facebook.png" class="iconoMapa"></a>
    </section>
    <section class="datosRedes">
      <a href="https://www.instagram.com/ruta66sevilla/?hl=es" target="blank"><img src="rsc/img/iconos/instagram.png" class="iconoMapa"></a>
    </section>
  </div>

</div>


<?php require_once 'templates/footer.php' ?>
