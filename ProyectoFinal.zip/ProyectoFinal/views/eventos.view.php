<?php require_once 'templates/header.php' ?>

<br>
<div class="contenedorSeparador">
	<hr class="lineaAmarilla">
	<h2 class="tituloSeparador">Próximos Eventos</h2>
	<hr class="lineaAmarilla">
</div>
<br>

<!-- Contenedor de los filtros -->
<div class="contenedorFiltro">
	<div class="cajaBotonFiltro">
		<button class="filtroEventos" id="filtroEventos">Ver Filtros</button>
	</div>
	<form name="formularioFiltro" action="" method="GET" class="formularioFiltro" id="formularioFiltro">
			<select class="elegirMes" id="elegirMes">
				<option value="mostrarTodosMeses" selected>Todos los meses</option>
				<option value="1">Enero</option>
				<option value="2">Febrero</option>
				<option value="3">Marzo</option>
				<option value="4">Abril</option>
				<option value="5">Mayo</option>
				<option value="6">Junio</option>
				<option value="7">Julio</option>
				<option value="8">Agosto</option>
				<option value="9">Septiembre</option>
				<option value="10">Octubre</option>
				<option value="11">Noviembre</option>
				<option value="12">Diciembre</option>
				
			</select>
			<select class="elegirPrecio" id="elegirPrecio">
				<option value="mostrarTodosPrecios">Todos los precios</option>
				<option value="libre">Gratuito</option>
				<option value="limitado">5.00€</option>
			</select>
	</div>

</form>

<!-- Bloque donde se pintan los eventos con un fetch -->
<section class="eventosFiltrados" id="eventosFiltrados"></section>
<br>


<?php require_once 'templates/footer.php' ?>