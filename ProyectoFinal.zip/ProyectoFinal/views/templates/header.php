<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="author" content="Paula Gomez">
	<meta name="copyright" content="Ruta66">
	<meta name="contact" content="paugombar@gmail.com">
	<meta name="description" content="Restaurante americano en Sevilla. Ambiente motero, cercano y cerveza fria. Disfruta de la experiencia en nuestro bar o pide a domicilio & Take Away.">
	<meta name="keywords" content="hamburguesa, local de ensayo, comida americana, restaurante americano sevilla, nachos, alitas, conciertos, blues, música rock, rock '80, rockabilly, comer en sevilla, restaurante americano, motos custom, coches clásicos">

	<link rel="stylesheet" type="text/css" href="css/comunStyle.css">
	<link rel="stylesheet" type="text/css" href="css/indexStyle.css">
	<link rel="stylesheet" type="text/css" href="css/cartaStyle.css">
	<link rel="stylesheet" type="text/css" href="css/eventoStyle.css">
	<link rel="stylesheet" type="text/css" href="css/reservaStyle.css">
	<link rel="stylesheet" type="text/css" href="css/loginStyle.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

	<link rel="icon" type="icon/png" href="rsc/img/favicon.png">

	<title>Ruta 66</title>

</head>
<body>

	<nav>
		<ul class="listaMenu">
			<li><a class="enlace enlacesNav" href="index.php">Inicio</a></li>
			<li><a class="enlace enlacesNav" href="carta.php">Carta</a></li>
			<li><a href="index.php"><img src="rsc/img/iconos/logo.png" class="imagenNav" alt="logo ruta 66"></a></li>
			<li><a class="enlace enlacesNav" href="eventos.php">Eventos</a></li>
			<li><a class="enlace enlacesNav" href="reserva.php">Reserva</a></li>
		</ul>

		<!-- Menú oculto desplegable en tablet y movil -->

		<div class="menuOculto" id="menuOculto">
			<div id="btnMenu">
				<img src="rsc/img/iconos/menuAzul.png" class="iconoMenu" id="iconoMenu">
			</div>
			<div class="menuDesplegable" id="menuDesplegable">
				<ul>
					<li><a class="enlace enlacesNav" href="index.php">Inicio</a></li>
					<hr class="lineaMenu">
					<li><a class="enlace enlacesNav" href="carta.php">Carta</a></li>
					<hr class="lineaMenu">
					<li><a class="enlace enlacesNav" href="eventos.php">Eventos</a></li>
					<hr class="lineaMenu">
					<li><a class="enlace enlacesNav" href="reserva.php">Reserva</a></li>
				</ul>
			</div>
		</div>


	</nav>

	

