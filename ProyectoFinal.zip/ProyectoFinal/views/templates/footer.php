<footer class="pie">
  <p class="pFooter">Proyecto de Paula Gómez Barragán</p>
</footer>


<script type="text/javascript" src="js/main.js"></script>
<script type="text/javascript" src="js/eventos.js"></script>
<script type="text/javascript" src="js/reservas.js"></script>


</body>
</html>