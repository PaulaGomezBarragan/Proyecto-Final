<?php require_once 'templates/header.php' ?>

<br>

<div class="contenedorSeparador">
	<hr class="lineaAmarilla">
	<h2 class="tituloSeparador">Sabor Americano</h2>
	<hr class="lineaAmarilla">
</div>


<!-- Contenedor para cada bloque de comida -->
<section class="contenedorMenu">

	<!-- Bucle para sacar los elementos de la base de datos y pintarlos -->
	<?php foreach ($comidas as $comida): ?>
		<?php if ($comida['ref']==='americano'): ?>

			<article class="contenedorComida">		
				<div class="foto">
					<img alt="<?php echo($comida['nombre']) ?>" class="fotoComida" src="rsc/img/comida/<?php echo $comida['imagen'] ?>">
				</div>
				<div class="plato">
					<h4 class="nombreComida"><?php echo $comida['nombre'] ?></h4>
					<span class="descripcionComida"><?php echo $comida['descripcion'] ?></span>

					<div class="contenedorAlergenos">
						<div class="alergenos">
							<!-- Bucle interno para sacar los alergenos -->
							<?php $arrayAlargenos=explode(' ', $comida['alargenos']); ?>
							<?php foreach ($arrayAlargenos as $alargeno): ?>
								<?php $array=explode(',', $alargeno) ?>
								<?php foreach ($array as $i): ?>
									<img title="<?php echo $i?>" src="rsc/img/alargenos/<?php echo $i.'.png' ?>" class="fotoAlargeno" >
								<?php endforeach ?>

							<?php endforeach ?>
						</div>
						<div class="precio">
							<span class="precio"><?php echo $comida['precio'] ?></span>
						</div>

					</div>
				</div>
			</article>

		<?php endif ?>
	<?php endforeach ?>
	
	
</section> 

<br>

<div class="contenedorSeparador">
	<hr class="lineaAmarilla">
	<h2 class="tituloSeparador">Hamburguesas</h2>
	<hr class="lineaAmarilla">
</div>

<!-- Contenedor para cada bloque de comida -->
<section class="contenedorMenu">

	<!-- Bucle para sacar los elementos de la base de datos y pintarlos -->
	<?php foreach ($comidas as $comida): ?>
		<?php if ($comida['ref']==='hamburguesas'): ?>

			<article class="contenedorComida">		
				<div class="foto">
					<img class="fotoComida" src="rsc/img/comida/<?php echo $comida['imagen'] ?>" alt="<?php echo($comida['nombre']) ?>">
				</div>
				<div class="plato">
					<h4 class="nombreComida"><?php echo $comida['nombre'] ?></h4>
					<p class="descripcionComida"><?php echo $comida['descripcion'] ?></p>

					<div class="contenedorAlergenos">
						<div class="alargenos">
							<!-- Bucle interno para sacar los alergenos -->
							<?php $arrayAlargenos=explode(' ', $comida['alargenos']); ?>
							<?php foreach ($arrayAlargenos as $alargeno): ?>
								<?php $array=explode(',', $alargeno) ?>
								<?php foreach ($array as $i): ?>
									<img title="<?php echo $i?>" src="rsc/img/alargenos/<?php echo $i.'.png' ?>" class="fotoAlargeno">
								<?php endforeach ?>

							<?php endforeach ?>
						</div>
						<span class="precio"><?php echo $comida['precio'] ?></span>
					</div>
				</div>
			</article>

		<?php endif ?>
	<?php endforeach ?>

	
</section> 
<br>
<p class="excepcion">*Todas las hamburguesas se pueden pedir sin gluten por 1€ más,  excepto las de quinoa, tofu y pollo-pavo.</p>

<br>

<div class="contenedorSeparador">
	<hr class="lineaAmarilla">
	<h2 class="tituloSeparador">Perritos</h2>
	<hr class="lineaAmarilla">
</div>

<!-- Contenedor para cada bloque de comida -->
<section class="contenedorMenu">

	<!-- Bucle para sacar los elementos de la base de datos y pintarlos -->
	<?php foreach ($comidas as $comida): ?>
		<?php if ($comida['ref']==='perritos'): ?>

			<article class="contenedorComida">		
				<div class="foto">
					<img class="fotoComida" src="rsc/img/comida/<?php echo $comida['imagen'] ?>" alt="<?php echo($comida['nombre']) ?>">
				</div>
				<div class="plato">
					<h4 class="nombreComida"><?php echo $comida['nombre'] ?></h4>
					<p class="descripcionComida"><?php echo $comida['descripcion'] ?></p>

					<div class="contenedorAlergenos">
						<div class="alargenos">
							<!-- Bucle interno para sacar los alergenos -->
							<?php $arrayAlargenos=explode(' ', $comida['alargenos']); ?>
							<?php foreach ($arrayAlargenos as $alargeno): ?>
								<?php $array=explode(',', $alargeno) ?>
								<?php foreach ($array as $i): ?>
									<img title="<?php echo $i?>" src="rsc/img/alargenos/<?php echo $i.'.png' ?>" class="fotoAlargeno">
								<?php endforeach ?>

							<?php endforeach ?>
						</div>
						<span class="precio"><?php echo $comida['precio'] ?></span>
					</div>
				</div>
			</article>

		<?php endif ?>
	<?php endforeach ?>
	
	
</section> 

<br>
<p class="excepcion">*Todos los hot dogs se pueden pedir sin gluten por 1 € más, excepto Hot Dog Illinois.</p>


<br>
<div class="contenedorSeparador">
	<hr class="lineaAmarilla">
	<h2 class="tituloSeparador">Otros Platos</h2>
	<hr class="lineaAmarilla">
</div>

<!-- Contenedor para cada bloque de comida -->
<section class="contenedorMenu">

	<!-- Bucle para sacar los elementos de la base de datos y pintarlos -->
	<?php foreach ($comidas as $comida): ?>
		<?php if ($comida['ref']==='platos'): ?>

			<article class="contenedorComida">		
				<div class="foto">
					<img class="fotoComida" src="rsc/img/comida/<?php echo $comida['imagen'] ?>" alt="<?php echo($comida['nombre']) ?>">
				</div>
				<div class="plato">
					<h4 class="nombreComida"><?php echo $comida['nombre'] ?></h4>
					<p class="descripcionComida"><?php echo $comida['descripcion'] ?></p>

					<div class="contenedorAlergenos">
						<div class="alargenos">
							<!-- Bucle interno para sacar los alergenos -->
							<?php $arrayAlargenos=explode(' ', $comida['alargenos']); ?>
							<?php foreach ($arrayAlargenos as $alargeno): ?>
								<?php $array=explode(',', $alargeno) ?>
								<?php foreach ($array as $i): ?>
									<img title="<?php echo $i?>" src="rsc/img/alargenos/<?php echo $i.'.png' ?>" class="fotoAlargeno">
								<?php endforeach ?>

							<?php endforeach ?>
						</div>
						<span class="precio"><?php echo $comida['precio'] ?></span>
					</div>
				</div>
			</article>

		<?php endif ?>
	<?php endforeach ?>
	
</section> 

<br>
<p class="excepcion">*Los sándwiches de melva o pollo pueden pedirse sin gluten por 1€ más y las patatas 4 salsas sin coste adicional.</p>

<br>
<div class="contenedorSeparador">
	<hr class="lineaAmarilla">
	<h2 class="tituloSeparador">Tapas</h2>
	<hr class="lineaAmarilla">
</div>

<!-- Contenedor para cada bloque de comida -->
<section class="contenedorMenu">

	<!-- Bucle para sacar los elementos de la base de datos y pintarlos -->
	<?php foreach ($comidas as $comida): ?>
		<?php if ($comida['ref']==='tapas'): ?>

			<article class="contenedorComida">		
				<div class="foto">
					<img class="fotoComida" src="rsc/img/comida/<?php echo $comida['imagen'] ?>" alt="<?php echo($comida['nombre']) ?>">
				</div>
				<div class="plato">
					<h4 class="nombreComida"><?php echo $comida['nombre'] ?></h4>
					<p class="descripcionComida"><?php echo $comida['descripcion'] ?></p>

					<div class="contenedorAlergenos">
						<div class="alargenos">
							<!-- Bucle interno para sacar los alergenos -->
							<?php $arrayAlargenos=explode(' ', $comida['alargenos']); ?>
							<?php foreach ($arrayAlargenos as $alargeno): ?>
								<?php $array=explode(',', $alargeno) ?>
								<?php foreach ($array as $i): ?>
									<img title="<?php echo $i?>" src="rsc/img/alargenos/<?php echo $i.'.png' ?>" class="fotoAlargeno">
								<?php endforeach ?>

							<?php endforeach ?>
						</div>
						<span class="precio"><?php echo $comida['precio'] ?></span>
					</div>
				</div>
			</article>

		<?php endif ?>
	<?php endforeach ?>
	
	
</section> 

<br>
<div class="contenedorSeparador">
	<hr class="lineaAmarilla">
	<h2 class="tituloSeparador">Montaditos</h2>
	<hr class="lineaAmarilla">
</div>

<!-- Contenedor para cada bloque de comida -->
<section class="contenedorMenu">

	<!-- Bucle para sacar los elementos de la base de datos y pintarlos -->
	<?php foreach ($comidas as $comida): ?>
		<?php if ($comida['ref']==='montaditos'): ?>

			<article class="contenedorComida">		
				<div class="foto">
					<img class="fotoComida" src="rsc/img/comida/<?php echo $comida['imagen'] ?>" alt="<?php echo($comida['nombre']) ?>">
				</div>
				<div class="plato">
					<h4 class="nombreComida"><?php echo $comida['nombre'] ?></h4>
					<p class="descripcionComida"><?php echo $comida['descripcion'] ?></p>

					<div class="contenedorAlergenos">
						<div class="alargenos">
							<!-- Bucle interno para sacar los alergenos -->
							<?php $arrayAlargenos=explode(' ', $comida['alargenos']); ?>
							<?php foreach ($arrayAlargenos as $alargeno): ?>
								<?php $array=explode(',', $alargeno) ?>
								<?php foreach ($array as $i): ?>
									<img title="<?php echo $i?>" src="rsc/img/alargenos/<?php echo $i.'.png' ?>" class="fotoAlargeno">
								<?php endforeach ?>

							<?php endforeach ?>
						</div>
						<span class="precio"><?php echo $comida['precio'] ?></span>
					</div>
				</div>
			</article>

		<?php endif ?>
	<?php endforeach ?>
	
</section> 

<br>
<p class="excepcion">*Todos los montaditos se pueden pedir sin gluten por 1 € más.</p>


<br>
<div class="contenedorSeparador">
	<hr class="lineaAmarilla">
	<h2 class="tituloSeparador">Ensaladas</h2>
	<hr class="lineaAmarilla">
</div>

<!-- Contenedor para cada bloque de comida -->
<section class="contenedorMenu">

	<!-- Bucle para sacar los elementos de la base de datos y pintarlos -->
	<?php foreach ($comidas as $comida): ?>
		<?php if ($comida['ref']==='ensaladas'): ?>

			<article class="contenedorComida">		
				<div class="foto">
					<img class="fotoComida" src="rsc/img/comida/<?php echo $comida['imagen'] ?>" alt="<?php echo($comida['nombre']) ?>">
				</div>
				<div class="plato">
					<h4 class="nombreComida"><?php echo $comida['nombre'] ?></h4>
					<p class="descripcionComida"><?php echo $comida['descripcion'] ?></p>

					<div class="contenedorAlergenos">
						<div class="alargenos">
							<!-- Bucle interno para sacar los alergenos -->
							<?php $arrayAlargenos=explode(' ', $comida['alargenos']); ?>
							<?php foreach ($arrayAlargenos as $alargeno): ?>
								<?php $array=explode(',', $alargeno) ?>
								<?php foreach ($array as $i): ?>
									<img title="<?php echo $i?>" src="rsc/img/alargenos/<?php echo $i.'.png' ?>" class="fotoAlargeno">
								<?php endforeach ?>

							<?php endforeach ?>
						</div>
						<span class="precio"><?php echo $comida['precio'] ?></span>
					</div>
				</div>
			</article>

		<?php endif ?>
	<?php endforeach ?>
	
	
</section> 

<br>
<div class="contenedorSeparador">
	<hr class="lineaAmarilla">
	<h2 class="tituloSeparador">Menu Kids</h2>
	<hr class="lineaAmarilla">
</div>

<!-- Contenedor para cada bloque de comida -->
<section class="contenedorMenu">

	<!-- Bucle para sacar los elementos de la base de datos y pintarlos -->
	<?php foreach ($comidas as $comida): ?>
		<?php if ($comida['ref']==='ninos'): ?>

			<article class="contenedorComida">		
				<div class="foto">
					<img class="fotoComida" src="rsc/img/comida/<?php echo $comida['imagen'] ?>" alt="<?php echo($comida['nombre']) ?>">
				</div>
				<div class="plato">
					<h4 class="nombreComida"><?php echo $comida['nombre'] ?></h4>
					<p class="descripcionComida"><?php echo $comida['descripcion'] ?></p>

					<div class="contenedorAlergenos">
						<div class="alargenos">
							<!-- Bucle interno para sacar los alergenos -->
							<?php $arrayAlargenos=explode(' ', $comida['alargenos']); ?>
							<?php foreach ($arrayAlargenos as $alargeno): ?>
								<?php $array=explode(',', $alargeno) ?>
								<?php foreach ($array as $i): ?>
									<img title="<?php echo $i?>" src="rsc/img/alargenos/<?php echo $i.'.png' ?>" class="fotoAlargeno">
								<?php endforeach ?>

							<?php endforeach ?>
						</div>
						<span class="precio"><?php echo $comida['precio'] ?></span>
					</div>
				</div>
			</article>

		<?php endif ?>
	<?php endforeach ?>
	
	
</section> 

<br>
<div class="contenedorSeparador">
	<hr class="lineaAmarilla">
	<h2 class="tituloSeparador">Postres</h2>
	<hr class="lineaAmarilla">
</div>

<!-- Contenedor para cada bloque de comida -->
<section class="contenedorMenu">

	<!-- Bucle para sacar los elementos de la base de datos y pintarlos -->
	<?php foreach ($comidas as $comida): ?>
		<?php if ($comida['ref']==='postres'): ?>

			<article class="contenedorComida">		
				<div class="foto">
					<img class="fotoComida" src="rsc/img/comida/<?php echo $comida['imagen'] ?>" alt="<?php echo($comida['nombre']) ?>">
				</div>
				<div class="plato">
					<h4 class="nombreComida"><?php echo $comida['nombre'] ?></h4>
					<p class="descripcionComida"><?php echo $comida['descripcion'] ?></p>

					<div class="contenedorAlergenos">
						<div class="alargenos">
							<!-- Bucle interno para sacar los alergenos -->s
							<?php $arrayAlargenos=explode(' ', $comida['alargenos']); ?>
							<?php foreach ($arrayAlargenos as $alargeno): ?>
								<?php $array=explode(',', $alargeno) ?>
								<?php foreach ($array as $i): ?>
									<img title="<?php echo $i?>" src="rsc/img/alargenos/<?php echo $i.'.png' ?>" class="fotoAlargeno">
								<?php endforeach ?>

							<?php endforeach ?>
						</div>
						<span class="precio"><?php echo $comida['precio'] ?></span>
					</div>
				</div>
			</article>

		<?php endif ?>
	<?php endforeach ?>
	
	
</section> 

<br>
<div class="contenedorSeparador">
	<hr class="lineaAmarilla">
	<h2 class="tituloSeparador">Bebidas</h2>
	<hr class="lineaAmarilla">
</div>

<div class="contenedorBebidas">
	<p class="excepcion">Contamos con una variedad de más de 50 cervezas internacionales: belgas, alemanas, irlandesas, italianas, japonesas, holandesas y muchas más. Nuestra selección abarca desde ipas a negras, de rojas a hidromiel. Ven a probar tu cerveza favorita o dejate aconsejar por el personal de barra.</p>
	<br>
	<p class="excepcion">Disponemos de dos tiradores de Estrella Galicia de bodega. Además, contamos con dos tiradores más: uno de Erdinger y otro de Estrella Galicia 1906.</p>
</div>
<br>


<?php require_once 'templates/footer.php' ?>