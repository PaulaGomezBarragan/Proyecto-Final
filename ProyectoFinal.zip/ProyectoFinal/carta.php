<?php 

require_once 'admin/config.php';
require_once 'funciones.php';

/*Comprobar si hay conexion*/
$conexion();

/*Sacar los datos de la base de datos*/
$comidas=$obtenerDatos('comida');

/*Si no hay nada que pintar, que mande al index*/
if(!$comidas){
	header('Location:index.php');
};

require_once 'views/carta.view.php';

?>