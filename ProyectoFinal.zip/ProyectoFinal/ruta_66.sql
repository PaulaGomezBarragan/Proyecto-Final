-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-01-2023 a las 17:17:56
-- Versión del servidor: 10.4.27-MariaDB
-- Versión de PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ruta_66`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administrador`
--

CREATE TABLE `administrador` (
  `id` int(11) NOT NULL,
  `usuario` text NOT NULL,
  `clave` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `administrador`
--

INSERT INTO `administrador` (`id`, `usuario`, `clave`) VALUES
(1, 'admin', '123'),
(2, 'pepe', '456'),
(3, 'bea', '789');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comida`
--

CREATE TABLE `comida` (
  `id` int(11) NOT NULL,
  `ref` text NOT NULL,
  `nombre` text NOT NULL,
  `imagen` text NOT NULL,
  `descripcion` text NOT NULL,
  `alargenos` text NOT NULL,
  `precio` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `comida`
--

INSERT INTO `comida` (`id`, `ref`, `nombre`, `imagen`, `descripcion`, `alargenos`, `precio`) VALUES
(13, 'hamburguesas', 'Black Angus 200 grs.', 'burguer1.jpg', 'Novillo irlandés con tomate, cheddar y bacon', 'lacteos,trigo,sesamo,huevos', '9.50€'),
(20, 'perritos', 'Hot Dog Simple', 'perrito1.jpg', 'Con patatas chips', 'lacteos,trigo,huevos', '2.50€'),
(24, 'platos', 'Nachos Gratinados', 'comida1.jpg', 'Con carne, tomate natural, maíz, jalapeños y mucho queso', 'lacteos,trigo', '6.50€'),
(25, 'platos', 'Patatas Gratinadas', 'comida1.jpg', 'Con bacon, mayonesa y mucho queso', 'lacteos', '5.50€'),
(26, 'platos', 'Sandwich vegetal (pollo o melva)', 'comida1.jpg', 'Con brotes tiernos, tomate, huevo duro, espárragos y mayonesa', 'trigo,pescado,garbanzos', '6.00€'),
(27, 'platos', 'Pechuga de Pollo', 'comida1.jpg', 'Con guarnición de patatas fritas o ensalada', 'noAlargeno', '5.00€'),
(28, 'platos', 'Patatas 4 Salsas', 'comida1.jpg', 'A elegir entre: alioli, miel-mostaza, curri y gaucha', 'lacteos,trigo,mostaza', '5.50€'),
(29, 'platos', 'Patatas Bravas', 'comida1.jpg', '', 'lacteos,trigo', '5.50€'),
(30, 'platos', 'Patatas Fritas AC/DC', 'comida1.jpg', 'Patatas fritas picantes', 'lacteos', '5.50€'),
(31, 'tapas', 'Patatas Alioli', 'comida1.jpg', '', 'lacteos', '3.00€'),
(32, 'tapas', 'Ensaladilla', 'comida1.jpg', 'De atún', 'lacteos,pescado,garbanzos,soja', '3.50€'),
(33, 'tapas', 'Alitas de Pollo', 'comida1.jpg', 'Hechas al horno con salsa BBQ', 'trigo', '5.00€'),
(34, 'tapas', 'Queso Viejo de Oveja', 'comida1.jpg', '', 'lacteos', '3.50€'),
(35, 'tapas', 'Queso de Cabra', 'comida1.jpg', 'Con mermelada (preguntar)', 'lacteos', '3.50€'),
(36, 'tapas', 'Chicharrón de Cádiz', 'comida1.jpg', '', 'lacteos', '3.00€'),
(37, 'tapas', 'Nachos con Queso', 'comida1.jpg', 'Con o sin picante', 'lacteos,trigo', '3.00€'),
(38, 'tapas', 'Pimientos del Piquillo', 'comida1.jpg', 'Con melva o anchoas', 'pescado', '3.50€'),
(39, 'montaditos', 'Chicharrón de Cádiz', 'bocata1.jpg', '', 'lacteos,trigo', '3.00€'),
(40, 'montaditos', 'Chorizo Picante', 'bocata1.jpg', '', 'trigo', '3.00€'),
(41, 'montaditos', 'Rulo de Cabra', 'bocata1.jpg', 'Con anchoas', 'lacteos,trigo,pescado', '3.50€'),
(42, 'montaditos', 'Queso Viejo', 'bocata1.jpg', 'Con anchoas', 'lacteos,trigo,pescado', '3.80€'),
(43, 'montaditos', 'Pollo Alioli', 'bocata1.jpg', 'Con lechuga, cebolla morada y tomate natural', 'lacteos,trigo', '3.80€'),
(44, 'montaditos', 'Pimientos del Piquillo', 'bocata1.jpg', 'Con melva o anchoas', 'pescado,trigo', '3.50€'),
(45, 'ensaladas', 'Aliño de Tomate', 'ensalada1.jpg', 'Con ajo y orégano. (Melva por 1€ más)', 'pescado', '5.00€'),
(46, 'ensaladas', 'Ensalada Ruta 66', 'ensalada1.jpg', 'Brotes tiernos, frutos secos, rulo de cabra, pollo a la parrilla y vinagreta de mostaza', 'lacteos,trigo', '6.50€'),
(47, 'ninos', 'Menú Ruta Kid', 'burguer1.jpg', 'Hamburguesa Ibérica simple o Hot Dog simple con patatas + bebida (zumo,refresco,agua) + postre + regalo', 'noAlargeno', '6.50€'),
(48, 'postres', 'Brownie', 'postre1.jpg', 'Con helado de vainilla, sirope de chocolate y nata', 'lacteos', '5.00€'),
(49, 'postres', 'Tarta de la Casa', 'postre2.jpg', 'Preguntar disponibilidad ', 'lacteos,huevos', '4.50€'),
(50, 'postres', 'Coulant', 'postre1.jpg', 'Con helado de vainilla, sirope de chocolate y nata', 'lacteos', '5.00€'),
(51, 'postres', 'Gofre', 'postre2.jpg', 'Con sirope de chocolate', 'lacteos', '2.50€'),
(52, 'postres', 'Helado Almendrado', 'postre1.jpg', '', 'lacteos', '2.80€'),
(68, 'americano', 'HotDog Illinois', 'perrito2.jpg', 'Carne de cerdo con salsa mostaza-miel, pepinillo dulce, cebolla, tomate natural y jalapeños', 'lacteos,huevos,mostaza,trigo,soja', '5.50€'),
(71, 'americano', 'Costillas Misouri', 'comida1.jpg', 'Carne de cerdo asada a baja temperatura, con salsa agridulce y patatas fritas', 'lacteos,trigo,soja', '9.50€'),
(72, 'americano', 'Taco Pastor Nuevo México', 'comida1.jpg', 'Cuatro tortitas con cerdo acompañado con cilantro, zumo de lima, cebolla, tomate y daditos de piña', 'lacteos,trigo,soja', '8.50€'),
(73, 'americano', 'Brisquet Sándwich Texas', 'bocata1.jpg', 'Tiras de carne de ternera asaa bañadas en salsa especial Ruta 66 en pan tostado con mantequilla', 'lacteos,trigo,soja', '9.00€'),
(74, 'americano', 'Burguer Pulled Pork Oklahoma', 'burguer1.jpg', 'Carne de cerdo asada a baja temperatura, deshilachada y mezclada con salsa especial Ruta 66', 'lacteos,trigo,soja,sesamo', '11.50€'),
(75, 'americano', 'Burguer California Style', 'burguer2.jpg', 'Ternera gallega 220g con brotes tiernos, queso havarti, aguacate y cebolla caramelizada', 'lacteos,trigo,soja,sesamo', '12.00€'),
(76, 'hamburguesas', 'Mini Black Angus', 'burguer1.jpg', '50grs. de carne de novillo irlandés, cheddar y bacon', 'lacteos,trigo,sesamo', '4.00€'),
(77, 'hamburguesas', 'Ibérica Simple', 'burguer2.jpg', '100grs. de carne con queso', 'lacteos,trigo,sesamo', '4.50€'),
(78, 'hamburguesas', 'Vaca Retinta', 'burguer1.jpg', '150grs. de carne retinta con cheddar, tomate y lechuga', 'lacteos,trigo,sesamo', '7.00€'),
(79, 'hamburguesas', 'Ibérica de Piñones', 'burguer2.jpg', '150grs. de carne rellena con piñones, acompañada de cheddar, lechuga y cebolla crujiente', 'lacteos,huevos,trigo,sesamo,cacahuete', '7.00€'),
(80, 'hamburguesas', 'Ruta 66', 'burguer1.jpg', '100grs. de carne ibérica con bacon, queso, cebolla frita y pimientos rojos', 'lacteos,trigo,sesamo', '6.00€');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventos`
--

CREATE TABLE `eventos` (
  `id` int(11) NOT NULL,
  `nombre` text NOT NULL,
  `imagen` text NOT NULL,
  `descripcion` text NOT NULL,
  `precio` text NOT NULL,
  `fecha` date NOT NULL,
  `entrada` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `eventos`
--

INSERT INTO `eventos` (`id`, `nombre`, `imagen`, `descripcion`, `precio`, `fecha`, `entrada`) VALUES
(1, 'Queen', 'evento1.jpg', 'Entrada libre hasta completar aforo. El concierto empieza a las 23:00', 'Gratuito', '2023-02-03', 'libre'),
(2, 'Nirvana', 'evento2.jpg', 'Entrada libre hasta completar aforo. El concierto empieza a las 23:00', 'Gratuito', '2023-02-10', 'libre'),
(3, 'Guns And Roses', 'evento3.jpg', 'Entrada hasta completar aforo. El concierto empieza a las 23:30', '5.00€', '2023-02-17', 'limitado'),
(4, 'Jam Session', 'evento1.jpg', 'Entrada libre hasta completar aforo. El concierto empieza a las 19:00', 'Gratuito', '2023-03-09', 'libre'),
(5, 'The Beatles', 'evento2.jpg', 'Entrada hasta completar aforo. El concierto empieza a las 23:30', '5.00€', '2023-04-14', 'limitado'),
(6, 'The Rolling Stone', 'evento3.jpg', 'Entrada libre hasta completar aforo. El concierto empieza a las 23:00', '5.00€', '2023-04-07', 'limitado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas`
--

CREATE TABLE `reservas` (
  `id` int(11) NOT NULL,
  `nombre` text NOT NULL,
  `apellidos` text NOT NULL,
  `correo` text NOT NULL,
  `telefono` int(9) NOT NULL,
  `fecha` date NOT NULL,
  `hora` text NOT NULL,
  `personas` text NOT NULL,
  `comentario` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `reservas`
--

INSERT INTO `reservas` (`id`, `nombre`, `apellidos`, `correo`, `telefono`, `fecha`, `hora`, `personas`, `comentario`) VALUES
(3, 'Pepe', 'Perez', 'pepe@pepe.es', 612456789, '2023-02-25', '14:00', '6 personas', 'Sin comentarios');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administrador`
--
ALTER TABLE `administrador`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `comida`
--
ALTER TABLE `comida`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `administrador`
--
ALTER TABLE `administrador`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `comida`
--
ALTER TABLE `comida`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT de la tabla `eventos`
--
ALTER TABLE `eventos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
