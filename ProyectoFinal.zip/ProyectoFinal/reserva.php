<?php 

require_once 'admin/config.php';
require_once 'funciones.php';

/*Comprobar si hay conexion*/
$conexion();

$errores='';

/*Setear los datos que recogemos del formulario*/
if(isset($_POST['submit'])){
    $fecha=$_POST['fecha'];
    $personas=$_POST['cantidadPersonas'];
    $hora=$_POST['horas'];
    $nombre=$sanear($_POST['nombre']);
    $apellidos=$sanear($_POST['apellidos']);
    $correo=$sanear($_POST['correo']);
    $telefono=$sanear($_POST['telefono']);
    $comentario=$sanear($_POST['descripcion']);

/*Comprobar que los campos no esten vacios y validarlos*/
    if(empty($nombre)){
        $errores.='<li>Debes rellenar el nombre</li>';
    };

    if(empty($apellidos)){
        $errores.='<li>Debes rellenar los apellidos</li>';
    };

    if(empty($correo)){
          $errores.='<li>Debes rellenar el campo correo</li>';
      }else{
         if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
             $errores.='<li>El formato del correo no es correcto</li>';
         };
     };

     if(empty($comentario)){
        $comentario='Sin comentarios';
     };

    if(empty($telefono)){
        $errores.='<li>Debes rellenar el telefono</li>';
    }else{
        if (!filter_var($telefono, FILTER_SANITIZE_NUMBER_INT)) {
            $errores.='<li>El formato del telefono no es correcto</li>';
        };
    };

/*Si no hay errores, que los envie a la base de datos*/
    if(empty($errores)){
        $subirReserva($nombre,$apellidos,$correo,$telefono,$fecha,$hora,$personas,$comentario);
    };
};



require_once 'views/reserva.view.php';

?>